# EpicureAi > 2023-11-29 5:52pm
https://universe.roboflow.com/wagon/epicureai

Provided by a Roboflow user
License: CC BY 4.0

